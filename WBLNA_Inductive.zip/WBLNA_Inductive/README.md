# WBLNA
Wide Bandwidth low noise amplifier 20Hz-20MHz 20/40dB
-----------------------------------------------------

The WBLNA is a low noise high bandwidth amplifier board.
It can be use to many purpose as noise measurement.

## Specs are :
- 20Hz to 20MHz -3dB bandwidth
- +20dB and +40dB gain individual outputs
- 50 Ohms input/output impedance
- AC or DC coupled input (support +/-20V in AC coupled mode).
- Single 12V@50mA DC input jack
- Low overall cost (~30€ of parts + PCB).

This project  is open source and has been designed using Kicad 5.0.2
The Githu repos include all design files like :
- LTspice simulation files and results
- Schematics
- Bill of materials with Mouser order code
- Picture of prototype
- Pulse mesurements
- Mechanical drawing
- And more...


Frex


